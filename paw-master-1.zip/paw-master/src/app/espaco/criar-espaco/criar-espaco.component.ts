import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-criar-espaco',
  templateUrl: './criar-espaco.component.html',
  styleUrls: ['./criar-espaco.component.css']
})
export class CriarEspacoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
