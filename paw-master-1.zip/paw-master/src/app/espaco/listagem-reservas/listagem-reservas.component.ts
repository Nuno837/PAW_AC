import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listagem-reservas',
  templateUrl: './listagem-reservas.component.html',
  styleUrls: ['./listagem-reservas.component.css']
})
export class ListagemReservasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
