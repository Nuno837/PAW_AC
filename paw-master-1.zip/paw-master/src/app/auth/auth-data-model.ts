export interface AuthData {
  nome: string;
  email: string;
  NIF: number;
  morada: string;
  password: string;
  numCartao: number;
  validade: Date;
  ccv: number;
}
