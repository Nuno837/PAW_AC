export enum TipoEspaco{
  OPENSPACE  = 'openspace',
  SALA_REUNIAO = 'sala-reuniao',
  SALA_FORMACAO = 'sala-formacao'
}
