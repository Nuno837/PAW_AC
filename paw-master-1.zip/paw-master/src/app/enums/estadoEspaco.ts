export enum EstadoEspaco{
  CONCLUÍDA  = 'cheio',
  PENDENTE = 'livre'
}
