export enum Estado{
  CONCLUÍDA  = 'concluída',
  PENDENTE = 'pendente'
}
